kubectl -n default apply -f /opt/course/2/2-pod.yaml
kubectl get pod
kubectl describe pod
