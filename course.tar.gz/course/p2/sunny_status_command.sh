kubectl -n sun get deploy sunny
